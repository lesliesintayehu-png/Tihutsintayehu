# Tihut — Personal Portfolio

A personalized portfolio based on a portfolio template, customized for Tihut.

## Personal details
- Name: **Tihut**
- Introduction: **Student & Creative mind**
- Email: **lesliesintayehu@gmail.com**
- GitHub: **https://github.com/lesliesintayehu-png**

## Files
- `index.html` — static portfolio page
- `index.php` — PHP portfolio page with a contact form
- `messages.php` — password-protected inbox for messages
- `style.css` — responsive soft-pink styling
- `config.example.php` — sample database and inbox settings
- `.gitignore` — keeps your real `config.php` out of Git

## Important hosting note
GitHub Pages can publish the static `index.html` page, but it does not run PHP or connect to MySQL. The PHP contact form and private inbox in `index.php` and `messages.php` need a PHP host with MySQL support. If you publish this repository with GitHub Pages, the static page is what visitors will see; PHP features will not work there.

## Running the PHP version locally
1. Copy this folder into `xampp/htdocs/tihut-portfolio/`.
2. Make a copy of `config.example.php` named `config.php`.
3. Set your database details and choose a strong, private inbox password in `config.php`.
4. Keep `config.php` private. Never upload it to a public repository.
5. Start Apache and MySQL in XAMPP.
6. Visit `http://localhost/tihut-portfolio/`.

## Before sharing
- The email address in the portfolio is public. Use an email address you are comfortable sharing.
- Do not add your GitHub password or any other account password to these files.
- The inbox password is only a placeholder in `config.example.php`; set a private one only if you deploy the PHP version on a suitable host.
- Review the project text and skills so they accurately describe your own experience.
- This project was customized from an existing portfolio template. Keep attribution where required by the template's license or your teacher's instructions.
