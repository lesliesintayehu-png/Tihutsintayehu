<?php
date_default_timezone_set('Africa/Addis_Ababa');

require_once __DIR__ . '/config.php';

$dbHost = DB_HOST;
$dbName = DB_NAME;
$dbUser = DB_USER;
$dbPass = DB_PASS;

$pdo = null;
$dbError = '';
$sent = isset($_GET['sent']);
$nameError = '';
$emailError = '';
$messageError = '';
$sendError = '';
$formName = '';
$formEmail = '';
$formMessage = '';

try {
 $pdo = new PDO("mysql:host=$dbHost;charset=utf8mb4", $dbUser, $dbPass, [
 PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
 PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
 PDO::ATTR_EMULATE_PREPARES => false
    ]);

 $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
 $pdo->exec("USE `$dbName`");
 $pdo->exec("CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(80) NOT NULL,
        email VARCHAR(120) NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (PDOException $error) {
 $pdo = null;
 $dbError = 'The database could not be reached. Make sure MySQL is running in XAMPP, then refresh this page.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $pdo !== null) {
 $formName = trim($_POST['name'] ?? '');
 $formEmail = trim($_POST['email'] ?? '');
 $formMessage = trim($_POST['message'] ?? '');

 if ($formName === '') {
 $nameError = 'Please enter your name.';
    } elseif (mb_strlen($formName) > 80) {
 $nameError = 'Your name must be 80 characters or fewer.';
    }

 if ($formEmail === '') {
 $emailError = 'Please enter your email address.';
    } elseif (!filter_var($formEmail, FILTER_VALIDATE_EMAIL)) {
 $emailError = 'Please enter a valid email address.';
    } elseif (mb_strlen($formEmail) > 120) {
 $emailError = 'Your email must be 120 characters or fewer.';
    }

 if ($formMessage === '') {
 $messageError = 'Please write a short message.';
    } elseif (mb_strlen($formMessage) > 2000) {
 $messageError = 'Your message must be 2000 characters or fewer.';
    }

 if ($nameError === '' && $emailError === '' && $messageError === '') {
 try {
 $insertMessage = $pdo->prepare('INSERT INTO messages (name, email, message) VALUES (?, ?, ?)');
 $insertMessage->execute([$formName, $formEmail, $formMessage]);
 header('Location: index.php?sent=1#contact');
 exit;
        } catch (PDOException $error) {
 $sendError = 'Your message could not be saved. Please try again in a moment.';
        }
    }
}

function escape($text)
{
 return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
}

$currentYear = date('Y');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tihut | Portfolio</title>
<meta name="description" content="Tihut’s personal portfolio showcasing web development interests, learning projects, and contact information.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='16' fill='%230f2a22'/%3E%3Ctext x='32' y='45' font-family='Arial' font-size='36' font-weight='700' fill='%23ffffff' text-anchor='middle'%3EL%3C/text%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Sora:wght@600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="style.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg site-nav sticky-top">
  <div class="container">
    <a class="navbar-brand" href="index.php#home" aria-label="Tihut portfolio home">
      <span class="brand-mark">L</span>
      <span class="brand-text">Tihut<small>Personal Portfolio</small></span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainMenu" aria-controls="mainMenu" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainMenu">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
        <li class="nav-item"><a class="nav-link active" href="#home">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#about">About Me</a></li>
        <li class="nav-item"><a class="nav-link" href="#projects">Projects</a></li>
        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
        <li class="nav-item ms-lg-3"><a class="btn-nav" href="messages.php"><i class="bi bi-envelope"></i> Messages</a></li>
      </ul>
    </div>
  </div>
</nav>

<header class="hero" id="home">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-lg-7">
        <span class="eyebrow"><span class="pulse-dot"></span> Welcome to my portfolio</span>
        <h1 class="hero-title">Hi, I'm <span class="name-underline">Tihut</span>.<br>Student &amp; Creative mind.</h1>
        <p class="hero-text">I am exploring frontend and backend technologies and learning how to build useful, accessible websites. This is where I share selected projects and track my progress.</p>
        <div class="d-flex flex-column flex-sm-row gap-3">
          <a class="btn-main" href="#projects">View My Projects <i class="bi bi-arrow-down-right"></i></a>
          <a class="btn-ghost" href="#contact">Contact Me <i class="bi bi-chat-dots"></i></a>
        </div>
        <div class="hero-facts">
          <div>
            <span>Role</span>
            <strong>Student</strong>
          </div>
          <div>
            <span>Learning style</span>
            <strong>Self-directed</strong>
          </div>
          <div>
            <span>Focus</span>
            <strong>Web Development</strong>
          </div>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="student-card">
          <div class="student-card-top">
            <span class="student-badge"><i class="bi bi-code-slash"></i> Student Developer</span>
            <div class="student-avatar">L</div>
            <h2>Tihut</h2>
            <p>Student &middot; Creative mind</p>
          </div>
          <div class="student-card-body">
            <p class="mini-label">Currently learning</p>
            <div class="learning-chips">
              <span>Backend Basics</span>
              <span>PHP</span>
              <span>MySQL</span>
              <span>Database Management</span>
            </div>
            <div class="student-card-foot"><span class="status-dot"></span> Learning, building, and improving every day</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>

<section class="section about-section" id="about">
  <div class="container">
    <div class="row g-5 align-items-start">
      <div class="col-lg-7">
        <p class="section-label">01 &mdash; About me</p>
        <h2 class="section-title">I enjoy turning ideas into thoughtful digital experiences.</h2>
        <p class="section-text">I am a student interested in web development. I enjoy creating websites and learning how frontend and backend technologies work together.</p>
        <p class="section-text">I keep developing my skills through hands-on projects, experimenting with layouts, accessibility, and the foundations of web development.</p>
        <div class="learning-grid">
          <div class="learning-item">
            <div class="learning-icon"><i class="bi bi-diagram-3"></i></div>
            <div>
              <strong>Backend Basics</strong>
              <span>How servers and requests work</span>
            </div>
          </div>
          <div class="learning-item">
            <div class="learning-icon"><i class="bi bi-filetype-php"></i></div>
            <div>
              <strong>PHP</strong>
              <span>Writing dynamic web pages</span>
            </div>
          </div>
          <div class="learning-item">
            <div class="learning-icon"><i class="bi bi-database"></i></div>
            <div>
              <strong>MySQL</strong>
              <span>Storing and reading data</span>
            </div>
          </div>
          <div class="learning-item">
            <div class="learning-icon"><i class="bi bi-table"></i></div>
            <div>
              <strong>Database Management</strong>
              <span>Keeping information organized</span>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="about-panel">
          <h3>At a glance</h3>
          <div class="info-row">
            <span>Name</span>
            <strong>Tihut</strong>
          </div>
          <div class="info-row">
            <span>Role</span>
            <strong>Student</strong>
          </div>
          <div class="info-row">
            <span>Learning style</span>
            <strong>Self-directed</strong>
          </div>
          <div class="info-row">
            <span>Focus</span>
            <strong>Web Development</strong>
          </div>
          <div class="info-row">
            <span>Currently learning</span>
            <strong>PHP &amp; MySQL</strong>
          </div>
          <div class="stack-box">
            <p>My learning stack</p>
            <div class="stack-tags">
              <span>HTML</span>
              <span>CSS</span>
              <span>JavaScript</span>
              <span>PHP</span>
              <span>MySQL</span>
              <span>Bootstrap</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section" id="projects">
  <div class="container">
    <div class="section-head">
      <div>
        <p class="section-label">02 &mdash; Projects</p>
        <h2 class="section-title">Selected work and learning projects.</h2>
      </div>
      <p class="section-note">A few examples of the skills I am exploring as I grow as a developer.</p>
    </div>
    <div class="row g-4">
      <div class="col-lg-6">
        <article class="project-card">
          <div class="project-visual visual-one">
            <span class="project-index">01</span>
            <div class="browser">
              <div class="browser-bar"><i></i><i></i><i></i></div>
              <div class="browser-page">
                <div class="mock-nav"><span></span><b></b></div>
                <div class="mock-title"></div>
                <div class="mock-title short"></div>
                <div class="mock-text"></div>
                <div class="mock-text short"></div>
                <div class="mock-cards"><span></span><span></span></div>
              </div>
            </div>
          </div>
          <div class="project-body">
            <span class="project-type">Frontend project</span>
            <h3>Personal Portfolio Website</h3>
            <p>A simple personal website introducing my skills and projects. I used HTML for the structure, CSS for the styling, and a little JavaScript for small interactions.</p>
            <div class="tech-list">
              <span>HTML</span>
              <span>CSS</span>
              <span>JavaScript</span>
            </div>
          </div>
        </article>
      </div>
      <div class="col-lg-6">
        <article class="project-card">
          <div class="project-visual visual-two">
            <span class="project-index">02</span>
            <div class="browser browser-dark">
              <div class="browser-bar"><i></i><i></i><i></i></div>
              <div class="browser-page">
                <div class="mock-nav"><span></span><b></b></div>
                <div class="mock-form">
                  <span></span>
                  <span></span>
                  <span class="tall"></span>
                  <b></b>
                </div>
              </div>
            </div>
          </div>
          <div class="project-body">
            <span class="project-type">Full stack project</span>
            <h3>PHP Portfolio Website</h3>
            <p>A PHP and MySQL learning project exploring form validation, database storage, and private message management.</p>
            <div class="tech-list">
              <span>PHP</span>
              <span>MySQL</span>
              <span>HTML</span>
              <span>CSS</span>
              <span>Bootstrap</span>
            </div>
          </div>
        </article>
      </div>
    </div>
  </div>
</section>

<section class="section pt-0" id="contact">
  <div class="container">
    <div class="contact-panel">
      <div class="row g-5 align-items-center">
        <div class="col-lg-5">
          <p class="section-label">03 &mdash; Contact</p>
          <h2>Say hi, ask a question, or share feedback.</h2>
          <p class="section-text">Have a question about my projects, or just want to say hello? Fill in the form and send me a message. You can reach me by email or send a message using the form.</p>
          <ul class="contact-details">
            <li>
              <div class="contact-icon"><i class="bi bi-building"></i></div>
              <div>
                <span>Learning style</span>
                <strong>Self-directed</strong>
              </div>
            </li>
            <li>
              <div class="contact-icon"><i class="bi bi-person"></i></div>
              <div>
                <span>Creator</span>
                <strong>Tihut</strong>
              </div>
            </li>
            <li>
              <div class="contact-icon"><i class="bi bi-envelope"></i></div>
              <div><span>Email</span><strong><a href="mailto:lesliesintayehu@gmail.com">lesliesintayehu@gmail.com</a></strong></div>
            </li>
            <li>
              <div class="contact-icon"><i class="bi bi-github"></i></div>
              <div><span>GitHub</span><strong><a href="https://github.com/lesliesintayehu-png" target="_blank" rel="noopener noreferrer">@lesliesintayehu-png</a></strong></div>
            </li>
            <li>
              <div class="contact-icon"><i class="bi bi-laptop"></i></div>
              <div>
                <span>Focus</span>
                <strong>Web Development</strong>
              </div>
            </li>
          </ul>
        </div>
        <div class="col-lg-7">
          <div class="form-card">
            <h3>Send me a message</h3>
            <p>All fields are required.</p>

 <?php if ($dbError !== ''): ?>
              <div class="alert alert-danger mb-4" role="alert"><i class="bi bi-exclamation-triangle me-1"></i> <?= escape($dbError) ?></div>
 <?php endif; ?>

 <?php if ($sent): ?>
              <div class="alert alert-success mb-4" role="alert"><i class="bi bi-check-circle me-1"></i> Thank you! Your message was sent successfully.</div>
 <?php endif; ?>

 <?php if ($sendError !== ''): ?>
              <div class="alert alert-danger mb-4" role="alert"><i class="bi bi-exclamation-triangle me-1"></i> <?= escape($sendError) ?></div>
 <?php endif; ?>

 <?php if ($nameError !== '' || $emailError !== '' || $messageError !== ''): ?>
              <div class="alert alert-danger mb-4" role="alert"><i class="bi bi-exclamation-circle me-1"></i> Please check the highlighted fields below.</div>
 <?php endif; ?>

            <form method="post" action="index.php#contact">
              <fieldset <?= $pdo === null ? 'disabled' : '' ?>>
                <div class="mb-3">
                  <label class="form-label" for="name">Your name</label>
                  <input class="form-control <?= $nameError !== '' ? 'is-invalid' : '' ?>" type="text" id="name" name="name" value="<?= escape($formName) ?>" placeholder="e.g. Your name" maxlength="80" required>
 <?php if ($nameError !== ''): ?>
                    <div class="invalid-feedback"><?= escape($nameError) ?></div>
 <?php endif; ?>
                </div>
                <div class="mb-3">
                  <label class="form-label" for="email">Your email</label>
                  <input class="form-control <?= $emailError !== '' ? 'is-invalid' : '' ?>" type="email" id="email" name="email" value="<?= escape($formEmail) ?>" placeholder="you@example.com" maxlength="120" required>
 <?php if ($emailError !== ''): ?>
                    <div class="invalid-feedback"><?= escape($emailError) ?></div>
 <?php endif; ?>
                </div>
                <div class="mb-3">
                  <label class="form-label" for="message">Your message</label>
                  <textarea class="form-control <?= $messageError !== '' ? 'is-invalid' : '' ?>" id="message" name="message" placeholder="Write a short message here..." maxlength="2000" required><?= escape($formMessage) ?></textarea>
 <?php if ($messageError !== ''): ?>
                    <div class="invalid-feedback"><?= escape($messageError) ?></div>
 <?php endif; ?>
                  <div class="form-text">Up to 2000 characters.</div>
                </div>
                <button class="btn-main" type="submit" name="send" value="1" <?= $pdo === null ? 'disabled' : '' ?>>Send Hi <i class="bi bi-send"></i></button>
              </fieldset>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<footer class="site-footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-5">
        <a class="footer-brand" href="index.php#home"><span class="brand-mark">L</span> Tihut</a>
        <p class="footer-text">Student exploring web design, frontend development, and backend fundamentals.</p>
      </div>
      <div class="col-6 col-lg-3">
        <p class="footer-title">Explore</p>
        <ul class="footer-links">
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About Me</a></li>
          <li><a href="#projects">Projects</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </div>
      <div class="col-6 col-lg-4">
        <p class="footer-title">Messages</p>
        <ul class="footer-links">
          <li><a href="mailto:lesliesintayehu@gmail.com"><i class="bi bi-envelope me-1"></i> Email Tihut</a></li>
          <li><a href="https://github.com/lesliesintayehu-png" target="_blank" rel="noopener noreferrer"><i class="bi bi-github me-1"></i> GitHub</a></li>
          <li><a href="messages.php"><i class="bi bi-inbox me-1"></i> Private inbox</a></li>
          <li><a href="#contact">Send a message</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?= $currentYear ?> Tihut. Designed and built by Tihut.</span>
      <a href="#home">Back to top <i class="bi bi-arrow-up"></i></a>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
